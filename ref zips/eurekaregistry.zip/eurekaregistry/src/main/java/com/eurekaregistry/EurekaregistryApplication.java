package com.eurekaregistry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaregistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaregistryApplication.class, args);
	}

}
